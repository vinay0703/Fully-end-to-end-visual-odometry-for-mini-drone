import matplotlib.pylab as plt
import pandas as pd

fig = plt.figure()

ax = plt.axes()

# Change the location of the file which you want to plot.
# Only one train and val file because there is no sequence in CNN.
# Also here it is 2d plot bcz we have considered height to be constant.

actual_location_data = "val_data/fileval0.xlsx"
predicted_location_data = "val_data/fileval_pred0.xlsx"

df = pd.read_excel(actual_location_data, sheet_name=0)
x, y = list(df['x']), list(df['y'])

df2 = pd.read_excel(predicted_location_data, sheet_name=0)
x2, y2 = list(df2['x']), list(df2['y'])

ax.plot(x, y, label='Actual Drone path') 
ax.plot(x2, y2, label='Predicted Drone path') 

plt.xlabel('x')
plt.ylabel('y')

plt.legend()
plt.grid()
plt.show()
