import matplotlib.pylab as plt
import pandas as pd

fig = plt.figure()

ax = plt.axes(projection='3d')

# Change the location of the file which you want to plot.

actual_location_data = "val_data/fileval6.xlsx"
predicted_location_data = "val_data/fileval_pred6.xlsx"

df = pd.read_excel(actual_location_data, sheet_name=0)
x, y, z = list(df['x']), list(df['y']), list(df['z'])

df2 = pd.read_excel(predicted_location_data, sheet_name=0)
x2, y2, z2 = list(df2['x']), list(df2['y']), list(df2['z'])

ax.plot3D(x, y, z, label='Actual Drone path') 
ax.plot3D(x2, y2, z2, label='Predicted Drone path') 

plt.legend()
plt.show()
