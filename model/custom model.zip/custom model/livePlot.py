import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.animation import FuncAnimation

plt.style.use('fivethirtyeight')

ax = plt.axes(projection='3d')

actual_location_data = "fileval3.xlsx"
predicted_location_data = "fileval_pred3.xlsx"

actual_df = pd.read_excel(actual_location_data, sheet_name=0)
_x1, _y1, _z1 = list(actual_df['x']), list(actual_df['y']), list(actual_df['z']) 

predicted_df = pd.read_excel(predicted_location_data, sheet_name=0)
_x2, _y2, _z2 = list(predicted_df['x']), list(predicted_df['y']), list(predicted_df['z'])
i = 0

def animate(i):
    if i >= len(_x1):
        ani.event_source.stop()
    i += 1
    x1, y1, z1 = _x1[:i], _y1[:i], _z1[:i]
    x2, y2, z2 = _x2[:i], _y2[:i], _z2[:i]
    plt.cla()
    ax.plot3D(x1, y1, z1, label='Actual path')
    ax.plot3D(x2, y2, z2, label='Predicted path')
    ax.set_xlim([min(min(x1), min(x2)), max(max(x1), max(x2))])

    plt.legend(loc='upper left')
    plt.tight_layout()


ani = FuncAnimation(plt.gcf(), animate, interval=10, repeat = False)

plt.tight_layout()
plt.show()
