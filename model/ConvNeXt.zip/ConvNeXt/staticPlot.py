import matplotlib.pylab as plt
import pandas as pd

# Keep this value as "train" for training plots and 
# "val" for validation plots.
# training_or_val = "train"
training_or_val = "val"

saving_location = "static plots/" + training_or_val + "/"
saving_file_name_prefix = training_or_val
saving_file_name_suffix = "mobilenet"
saving_file_format = ".png"

# actual_data_file_name_prefix = "training_data/file" + training_or_val
actual_data_file_name_prefix = "validation_data/file" + training_or_val
actual_data_file_name_suffix = "mobilenet.xlsx"

# predicted_data_file_name_prefix = "training_data/file" + training_or_val +"_pred"
predicted_data_file_name_prefix = "validation_data/file" + training_or_val +"_pred"
predicted_data_file_name_suffix = "mobilenet.xlsx"

number_of_files = 11

for i in range(0, number_of_files+1):
	fig = plt.figure()
	ax = plt.axes(projection='3d')
	
	actual_location_data = actual_data_file_name_prefix + str(i) + actual_data_file_name_suffix
	df = pd.read_excel(actual_location_data, sheet_name=0)
	x, y, z = list(df['x']), list(df['y']), list(df['z'])

	predicted_location_data = predicted_data_file_name_prefix + str(i) + predicted_data_file_name_suffix
	df2 = pd.read_excel(predicted_location_data, sheet_name=0)
	x2, y2, z2 = list(df2['x']), list(df2['y']), list(df2['z'])

	ax.plot3D(x, y, z, label='Actual Drone path') 
	ax.plot3D(x2, y2, z2, label='Predicted Drone path') 
	
	plt.legend()
	
	ax.set_xlabel('x')	
	ax.set_ylabel('y')
	ax.set_zlabel('z')
		
	plt.savefig(saving_location + saving_file_name_prefix + str(i) + saving_file_name_suffix + saving_file_format)
	
	plt.clf()
