import matplotlib.pylab as plt
import pandas as pd

fig = plt.figure()

ax = plt.axes(projection='3d')

actual_location_data = "fileval_fixed0.xlsx"
predicted_location_data = "fileval_pred_fixed0.xlsx"

df = pd.read_excel(actual_location_data, sheet_name=0)
x, y, z = list(df['x']), list(df['y']), list(df['z'])

df2 = pd.read_excel(predicted_location_data, sheet_name=0)
x2, y2, z2 = list(df2['x']), list(df2['y']), list(df2['z'])

ax.plot3D(x, y, z, label='Actual Drone path') 
ax.plot3D(x2, y2, z2, label='Predicted Drone path') 

ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')

plt.legend()
plt.show()
